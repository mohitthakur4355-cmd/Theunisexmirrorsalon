export type ServiceCategory = 
  | 'all'
  | 'mens-hair'
  | 'mens-grooming'
  | 'womens-hair'
  | 'hair-treatments'
  | 'skincare-facials'
  | 'manicure-pedicure'
  | 'bridal-party';

export interface ServiceItem {
  id: string;
  name: string;
  category: ServiceCategory;
  price: number;
  duration: string;
  description: string;
  popular?: boolean;
  tag?: string;
  gender: 'unisex' | 'men' | 'women' | 'kids';
  image: string;
}

export interface ServicePackage {
  id: string;
  name: string;
  target: 'Groom' | 'Bride' | 'Special' | 'Combo';
  originalPrice: number;
  packagePrice: number;
  duration: string;
  popular?: boolean;
  features: string[];
  description: string;
  badge?: string;
}

export interface ReviewItem {
  id: string;
  author: string;
  rating: number;
  date: string;
  service: string;
  comment: string;
  avatar: string;
  verified: boolean;
}

export interface LookbookItem {
  id: string;
  title: string;
  category: 'men' | 'women' | 'bridal' | 'nails' | 'treatments';
  imageUrl: string;
  caption: string;
}

export interface BeforeAfterItem {
  id: string;
  title: string;
  description: string;
  beforeImage: string;
  afterImage: string;
  serviceName: string;
}

export interface StylistMember {
  id: string;
  name: string;
  role: string;
  experience: string;
  specialty: string[];
  avatar: string;
}

export interface BookingFormData {
  serviceIds: string[];
  date: string;
  timeSlot: string;
  stylist: string;
  customerName: string;
  customerPhone: string;
  customerGender: string;
  notes: string;
}