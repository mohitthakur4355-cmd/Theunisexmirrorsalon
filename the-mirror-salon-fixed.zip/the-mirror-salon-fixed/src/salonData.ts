import { ServiceItem, ServicePackage, ReviewItem, LookbookItem, BeforeAfterItem, StylistMember } from '../types';

export const SALON_INFO = {
  name: "The Mirror Unisex Salon",
  tagline: "Agra's Signature Luxury Hair, Beauty & Bridal Destination",
  address: "FF-1, Shopping Arcade, Next to Domino's, Karkunj Road, Sikandra, Agra, Uttar Pradesh 282007",
  landmark: "Next to Domino's Pizza, Karkunj Road",
  phone: "+91 94122 66088",
  rawPhone: "919412266088",
  rating: 4.6,
  reviewsCount: 440,
  timing: "9:00 AM – 9:00 PM (Daily)",
  googleMapsUrl: "https://maps.google.com/?q=The+Mirror+Unisex+Salon+Sikandra+Agra",
  coordinates: {
    lat: 27.2043,
    lng: 77.9542
  }
};

export const SALON_SERVICES: ServiceItem[] = [
  {
    id: 'men-classic-cut',
    name: 'Precision Signature Haircut & Styling',
    category: 'mens-hair',
    price: 250,
    duration: '30 mins',
    description: 'Bespoke consultation, hair wash, precision shear cut, texturizing, and matte pomade styling.',
    popular: true,
    tag: 'Bestseller',
    gender: 'men',
    image: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'men-haircut-shave-combo',
    name: 'Royal Cut + Hot Towel Beard Sculpting',
    category: 'mens-grooming',
    price: 450,
    duration: '45 mins',
    description: 'Complete grooming package with hair shaping, hot steam towel, straight-edge razor beard lining, and soothing balm.',
    popular: true,
    tag: 'Popular Combo',
    gender: 'men',
    image: 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'women-advance-layer',
    name: 'Advance Multi-Layer Cut & Blow Dry',
    category: 'womens-hair',
    price: 550,
    duration: '45 mins',
    description: 'Face-framing feather or step layers tailored to your face silhouette, with deep conditioning wash and Moroccan oil blow dry.',
    popular: true,
    tag: 'Client Favorite',
    gender: 'women',
    image: 'https://images.unsplash.com/photo-1560869713-7d0a29430803?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'treatment-keratin-smoothing',
    name: 'Brazilian Keratin Protein Smoothing',
    category: 'hair-treatments',
    price: 3499,
    duration: '150 mins',
    description: 'Eliminate frizz, seal split ends, and restore mirror-like shine lasting 4–6 months with premium formaldehyde-free keratin.',
    popular: true,
    tag: 'Signature Treatment',
    gender: 'unisex',
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'facial-o3-whitening',
    name: 'O3+ Diamond Radiance Glow Facial',
    category: 'skincare-facials',
    price: 1800,
    duration: '60 mins',
    description: 'Instant pigmentation reduction, deep cellular exfoliation, ultrasonic serum infusion, and luminous whitening peel.',
    popular: true,
    tag: 'Glow Favorite',
    gender: 'unisex',
    image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'nail-crystal-pedi',
    name: 'Crystal Advance Spa Pedicure',
    category: 'manicure-pedicure',
    price: 799,
    duration: '50 mins',
    description: 'Aromatherapy crystal soak, dead skin peel, cuticle nourishment, revitalizing massage, and high-shine polish.',
    gender: 'unisex',
    image: 'https://images.unsplash.com/photo-1519014816548-bf5fe059798b?auto=format&fit=crop&w=600&q=80'
  }
];

export const SERVICE_PACKAGES: ServicePackage[] = [
  {
    id: 'groom-royal-pass',
    name: 'The Royal Maharaja Groom Makeover',
    target: 'Groom',
    originalPrice: 4800,
    packagePrice: 3199,
    duration: '3.5 Hours',
    popular: true,
    badge: 'Save ₹1,600',
    description: 'Complete pre-wedding grooming package designed for the modern groom.',
    features: [
      'Precision Signature Haircut & Beard Sculpting',
      'O3+ Diamond Glow Facial with D-Tan Pack',
      'L\'Oréal Mythic Oil Deep Hair Spa Therapy',
      'Deluxe Crystal Manicure & Foot Spa Pedicure',
      'Pre-wedding Skin Consultation & Beard Setting'
    ]
  },
  {
    id: 'bridal-hd-pass',
    name: 'Regal Maharani HD Bridal Experience',
    target: 'Bride',
    originalPrice: 12500,
    packagePrice: 8499,
    duration: '4.5 Hours',
    popular: true,
    badge: 'Most Booked Bridal',
    description: 'Flawless luxury bridal makeover designed for timeless wedding photography.',
    features: [
      'High-Definition (HD) Waterproof Bridal Makeup',
      'Intricate Designer Hairdos with Hair Extensions',
      'Dupatta Draping & Real Floral / Jewelry Placement',
      'Pre-Bridal O3+ Glow & Radiance Cleanup',
      'Gel Nail Extensions with Crystal Finish'
    ]
  }
];

export const SALON_REVIEWS: ReviewItem[] = [
  {
    id: 'rev-1',
    author: 'Aman Sharma',
    rating: 5,
    date: '2 weeks ago',
    service: 'Haircut & Beard Sculpting',
    comment: 'Best salon experience in Sikandra Agra! The stylists take their time to understand what cut suits your face. Very clean and hygienic environment.',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    verified: true
  },
  {
    id: 'rev-2',
    author: 'Pooja Agarwal',
    rating: 5,
    date: '1 month ago',
    service: 'Keratin Hair Treatment & Facial',
    comment: 'Got my keratin smoothing done here before my brother’s wedding. The shine and softness is unbelievable! 100% recommended.',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
    verified: true
  }
];

export const LOOKBOOK_ITEMS: LookbookItem[] = [
  {
    id: 'look-1',
    title: 'Textured Crop Fade',
    category: 'men',
    imageUrl: 'https://images.unsplash.com/photo-1622286342621-4bd786c2447c?auto=format&fit=crop&w=600&q=80',
    caption: 'Clean high fade with natural matte volume'
  },
  {
    id: 'look-2',
    title: 'Honey Caramel Balayage',
    category: 'women',
    imageUrl: 'https://images.unsplash.com/photo-1560869713-7d0a29430803?auto=format&fit=crop&w=600&q=80',
    caption: 'Sun-kissed seamless blend with glossy finish'
  }
];

export const BEFORE_AFTER_ITEMS: BeforeAfterItem[] = [
  {
    id: 'ba-1',
    title: 'Damaged Frizzy Hair to Mirror Silk Keratin',
    serviceName: 'Keratin Smoothing',
    description: '3 hours of deep protein infusion turned unruly, chemically dried hair into ultra-smooth, glossy locks.',
    beforeImage: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=800&q=80',
    afterImage: 'https://images.unsplash.com/photo-1605497788044-5a32c7078486?auto=format&fit=crop&w=800&q=80'
  }
];

export const TEAM_MEMBERS: StylistMember[] = [
  {
    id: 'team-1',
    name: 'Rohit Verma',
    role: 'Master Creative Stylist & Colorist',
    experience: '8+ Years Experience',
    specialty: ['Fade Precision', 'Balayage Color', 'Beard Artistry'],
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'
  }
];

export const FAQS = [
  {
    question: "Do I need an appointment or can I walk in?",
    answer: "Walk-ins are always warmly welcomed! However, to avoid waiting during peak hours (especially evenings and weekends), we recommend booking an appointment online or via WhatsApp."
  },
  {
    question: "Where exactly is the salon located in Sikandra?",
    answer: "We are located at FF-1, Shopping Arcade, right next to Domino's Pizza on Karkunj Road, Sikandra, Agra with ample free parking."
  },
  {
    question: "What payment methods do you accept?",
    answer: "We accept all UPI payment apps (Google Pay, PhonePe, Paytm), Debit/Credit Cards, and Cash."
  }
];